# Breast Cancer in Florida: Data Analysis Project

This project explores breast cancer trends, demographics, and outcomes in the state of Florida using public health datasets.

## Objectives
- Analyze breast cancer incidence and mortality across Florida.
- Investigate demographic and socioeconomic correlations.
- Optional: Build predictive models for survival or risk.

## Project Structure
- `data/`: Raw and processed data
- `notebooks/`: Jupyter notebooks for EDA and modeling
- `scripts/`: Python scripts for data handling and analysis
- `reports/`: Visual summaries and insights

## Data Sources
- CDC Cancer Data
- Florida Department of Health (FL CHARTS)
- U.S. Census

## Setup
```bash
pip install -r requirements.txt
```

## License
MIT License
